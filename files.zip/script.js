// ---------------------------------------------------------------
// Mobile nav toggle
// ---------------------------------------------------------------
const navToggle = document.getElementById('navToggle');
const primaryNav = document.getElementById('primaryNav');

navToggle.addEventListener('click', () => {
  const isOpen = primaryNav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
});

primaryNav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    primaryNav.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

// ---------------------------------------------------------------
// Scrollspy — highlight the nav link for the section in view
// ---------------------------------------------------------------
const sections = document.querySelectorAll('main section[id]');
const navLinks = document.querySelectorAll('[data-nav]');

const spyObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.getAttribute('id');
      navLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
      });
    }
  });
}, { rootMargin: '-45% 0px -50% 0px' });

sections.forEach(section => spyObserver.observe(section));

// ---------------------------------------------------------------
// Footer year
// ---------------------------------------------------------------
document.getElementById('year').textContent = new Date().getFullYear();

// ---------------------------------------------------------------
// Hero circuit diagram — draw traces once on load, then light up
// each endpoint node in sequence. Skips straight to the final
// state if the user prefers reduced motion.
// ---------------------------------------------------------------
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const traces = document.querySelectorAll('#circuitSvg .trace');
const endpoints = document.querySelectorAll('#circuitSvg .endpoint');

if (prefersReducedMotion) {
  traces.forEach(t => t.classList.add('drawn'));
  endpoints.forEach(e => e.classList.add('lit'));
} else {
  traces.forEach((trace, i) => {
    const length = trace.getTotalLength();
    trace.style.strokeDasharray = length;
    trace.style.strokeDashoffset = length;

    // Force reflow so the initial state is applied before transitioning
    trace.getBoundingClientRect();

    trace.style.transition = `stroke-dashoffset 0.9s ease ${i * 0.15}s`;
    requestAnimationFrame(() => {
      trace.style.strokeDashoffset = '0';
    });

    // Light up the corresponding endpoint once its trace finishes drawing
    const endpoint = endpoints[i];
    if (endpoint) {
      setTimeout(() => {
        trace.classList.add('drawn');
        endpoint.classList.add('lit');
      }, (i * 150) + 900);
    }
  });
}
